﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BOL;
namespace BLL
{
    public class BusinessManager
    {
        public static List<Employee> GetAllEmployees()
        {
            List<Employee> allEmployess = new List<Employee>();
            allEmployess = DBManager.GetAllEmployees();
            return allEmployess;

        }
       /* public static List<Customer> InsertCustomer()
        {
            List<Customer> addCustomer = new List<Customer>();
            addCustomer = DBManager.AddNewCustomer();
            return addCustomer;
        }*/

        public static List<Books> GetAllBooks()
        {
            List<Books> allBooks = new List<Books>();
            allBooks = DBManager.GetAllBooks();
            return allBooks;
        }
        public static Books GetBooks(int id)
        {
            return DBManager.GetBooksById(id);
        }
        public static bool InsertCustomer(Customer theCustomer)
        {
            return DBManager.AddNewCustomer(theCustomer);
        }

        public static Books InsertBook(Books thebook)

        {
            return DBManager.InsertBook(thebook);
        }
        public static bool validateUser(string email,string password)
        {
            return DBManager.validateUser(email, password);
        }
        public static Employee getEmployeeById(int id)
        {
            return DBManager.getEmployeeById(id);
        }
        public static bool UpdateBook(Books book)
        {
            return DBManager.UpdateBook(book);
        }

        public static bool DeleteById(int id)
        {
            return DBManager.DeleteById(id);
        }
    }
}

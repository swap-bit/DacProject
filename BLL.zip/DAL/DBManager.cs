﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;
using BOL;
namespace DAL
{
    public class DBManager
    {

        public static readonly string connString = string.Empty;
        static DBManager()
        {
            connString = ConfigurationManager.ConnectionStrings["dbString"].ConnectionString;

        }

        public static Books GetBooksById(int id)
        {
            Books usedBooks = new Books();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from Books where BookId=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {

                    usedBooks.ID = int.Parse(row["BookID"].ToString());
                    usedBooks.Title = row["BookName"].ToString();
                    usedBooks.Author = row["BookAuthor"].ToString();
                    usedBooks.ImageUrl = row["BookImage"].ToString();
                    usedBooks.Description = row["BookDescription"].ToString();
                    usedBooks.Price = double.Parse(row["BookPrice"].ToString());

                }

            }
            catch (MySqlException e)
            {
                string message = e.Message;
            }

            return usedBooks;
        }

        public static List<Books> GetAllBooks()
        {
            List<Books> theBook = new List<Books>();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from Books";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    Books theBooks = new Books();
                    theBooks.ID = int.Parse(row["BookId"].ToString());
                    theBooks.Title = row["BookName"].ToString();
                    theBooks.Author = row["BookAuthor"].ToString();
                    theBooks.Description = row["BookDescription"].ToString();
                    theBooks.ImageUrl = row["BookImage"].ToString();
                    theBooks.Price = double.Parse(row["BookPrice"].ToString());
                    theBooks.Quantity = int.Parse(row["BookQuantity"].ToString());
                    theBook.Add(theBooks);
                }

            }
            catch (MySqlException e)
            {
                string message = e.Message;
            }
            return theBook;

        }

        public static List<Employee> GetAllEmployees()
        {
            List<Employee> allemployee = new List<Employee>();
            //implement ado.net logic to fetch all records from database
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from Employee";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    Employee theEmployee = new Employee();
                    theEmployee.ID = int.Parse(row["EmployeeID"].ToString());
                    theEmployee.Name = row["EmployeeName"].ToString();
                    theEmployee.Email = row["EmployeeEmail"].ToString();
                    theEmployee.ContactNumber = row["EmployeeContact"].ToString();
                    theEmployee.Role = row["EmployeeRole"].ToString();
                    allemployee.Add(theEmployee);
                }

            }
            catch (MySqlException e)
            {
                string message = e.Message;
            }
            return allemployee;
        }

        public static  bool   AddNewCustomer(Customer theCustomer)
        {
            {

                bool status = false;
                try
                {
                    using (MySqlConnection con = new MySqlConnection(connString))
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        string query = "INSERT INTO Customers (CustomerName,CustomerEmail, CustomerPassword, CustomerAddress, ContactNumber) " +
                            "VALUES (@name, @email, @password, @address, @contact)";
                        MySqlCommand cmd = new MySqlCommand(query, con);
                        cmd.Parameters.Add(new MySqlParameter("@name", theCustomer.Name));
                        cmd.Parameters.Add(new MySqlParameter("@email", theCustomer.Email));
                        cmd.Parameters.Add(new MySqlParameter("@password", theCustomer.Password));
                        cmd.Parameters.Add(new MySqlParameter("@address", theCustomer.Address));
                        cmd.Parameters.Add(new MySqlParameter("@contact", theCustomer.ContactNumber));

                        cmd.ExecuteNonQuery();// DML

                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
                catch (MySqlException ex)
                {
                    string message = ex.Message;
                    throw ex;
                }
                return status;
               
               
            }



        }

        public static bool validateUser(string LoginName, string Password)
        {
            bool status = false;
            IDbConnection con = new MySqlConnection(connString);
            //SQL DB Injection Problem
            string query = "SELECT * FROM Customers WHERE CustomerEmail= @username AND CustomerPassword =@password";
            IDbCommand cmd = new MySqlCommand(query);
            cmd.Parameters.Add(new MySqlParameter("username", LoginName));
            cmd.Parameters.Add(new MySqlParameter("password", Password));
            cmd.Connection = con;
            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    status = true;
                }
                reader.Close();
                con.Close();
            }
            catch (MySqlException)
            {
            }
            return status;



        }

        public static Employee getEmployeeById(int id)
        {
            Employee employees = new Employee();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from Employee where EmployeeID=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {

                    employees.ID = int.Parse(row["EmployeeID"].ToString());
                    employees.Name = row["EmployeeName"].ToString();
                    employees.Email = row["EmployeeEmail"].ToString();
                    employees.ContactNumber = row["EmployeeContact"].ToString();
                    employees.Role = row["EmployeeRole"].ToString();

                }

            }
            catch (MySqlException e)
            {
                string message = e.Message;
            }

            return employees;
        }

        public static Books InsertBook(Books theBook)
        {
            {

               // theBook = new Books();
               // bool status = false;
                try
                {
                    using (MySqlConnection con = new MySqlConnection(connString))
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        string query = "INSERT INTO Books (BookName,BookAuthor, BookImage, BookDescription, BookPrice,BookQuantity) " +
                            "VALUES ( @title, @author, @imageurl, @description, @price,@quantity)";
                        MySqlCommand cmd = new MySqlCommand(query, con);
                        //cmd.Parameters.Add(new MySqlParameter("@id", theBook.ID));
                        cmd.Parameters.Add(new MySqlParameter("@title", theBook.Title));
                        cmd.Parameters.Add(new MySqlParameter("@author", theBook.Author));
                        cmd.Parameters.Add(new MySqlParameter("@imageurl", theBook.ImageUrl));
                        cmd.Parameters.Add(new MySqlParameter("@description", theBook.Description));
                        cmd.Parameters.Add(new MySqlParameter("@price", theBook.Price));
                        cmd.Parameters.Add(new MySqlParameter("@quantity", theBook.Quantity));
                        cmd.ExecuteNonQuery();// DML

                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
                catch (MySqlException ex)
                {
                    string message = ex.Message;
                    throw ex;
                }
                return theBook;


            }



        }

        public static bool UpdateBook(Books theBook)
        {
            bool status = false;
            //Books thebook = new Books();
            IDbConnection con = new MySqlConnection(connString);
            string query = "UPDATE Books SET BookName=@Title ,BookAuthor=@Author,BookImage=@Image, BookDescription=@Description, " +
                         "BookPrice=@Price, BookQuantity=@Quantity " +
                        "WHERE BookID=@Id";
            IDbCommand cmd = new MySqlCommand(query);
            cmd.Parameters.Add(new MySqlParameter("@Id", theBook.ID));
            cmd.Parameters.Add(new MySqlParameter("@Title", theBook.Title));
            cmd.Parameters.Add(new MySqlParameter("@Author", theBook.Author));
            cmd.Parameters.Add(new MySqlParameter("@Image", theBook.ImageUrl));
            cmd.Parameters.Add(new MySqlParameter("@Description", theBook.Description));
            cmd.Parameters.Add(new MySqlParameter("@Price", theBook.Price));
            cmd.Parameters.Add(new MySqlParameter("@Quantity", theBook.Quantity));
            cmd.Connection = con;
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                status = true;
            }
            catch (MySqlException ex)
            {
                string message = ex.Message;
                throw ex;
            }
            
            return status;
        }
        public static bool DeleteById(int id)
        {
            bool status = false;
            IDbConnection con = new MySqlConnection(connString);
            string query = "DELETE FROM Books where BookID=@id";
            IDbCommand cmd = new MySqlCommand(query);
            cmd.Parameters.Add(new MySqlParameter("@id", id));
            cmd.Connection = con;
            try
            {
                con.Open();
                var reader = cmd.ExecuteNonQuery();
                con.Close();
                status = true;
                
            }
            catch (MySqlException ex)
            {
                string message = ex.Message;
                throw ex;
            }

            return status;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Http;
using System.Web.Http.Cors;
using BLL;
using BOL;
namespace RestApi.Controllers
{
    [EnableCors(origins:"*",headers:"*",methods:"*")]
    public class BooksController : ApiController
    {
        // GET: api/Books
        public IEnumerable<Books> Get()
        {
            return BusinessManager.GetAllBooks();
        }

        // GET: api/Books/5
        public Books Get(int id)
        {
            return BusinessManager.GetBooks(id);
        }

        // POST: api/Books
        
        public Books Post([FromBody]Books theBooks)
        {
           return  BusinessManager.InsertBook(theBooks);
           // return Ok;
          
        }
        //put method can be used for updating the information
        // PUT: api/Books/5

        public void  Put(int id, [FromBody] Books value)
        {
              BusinessManager.UpdateBook(value);
        }

        // DELETE: api/Books/5
        public bool Delete(int id)
        {
            return BusinessManager.DeleteById(id);
        }
    }
}

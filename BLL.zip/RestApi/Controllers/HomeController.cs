﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BLL;
using BOL;
namespace RestApi.Controllers
{
    public class HomeController : ApiController
    {
        // GET: api/Home
        public IEnumerable<Employee> Get()
        {
           return BusinessManager.GetAllEmployees();
        }

        // GET: api/Home/5
        public Employee Get(int id)
        {
            return BusinessManager.getEmployeeById(id);
        }

        // POST: api/Home
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Home/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Home/5
        public void Delete(int id)
        {
        }
    }
}
